﻿using System.Windows.Forms;

namespace My_File_Explorer
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }
        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.mainMenu = new System.Windows.Forms.MenuStrip();
            this.mnuItmFile = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuItmClose = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuItmHelp = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuItmAbout = new System.Windows.Forms.ToolStripMenuItem();
            this.tvFolders = new System.Windows.Forms.TreeView();
            this.imgListTreeView = new System.Windows.Forms.ImageList(this.components);
            this.lvFolders = new System.Windows.Forms.ListView();
            this.mainMenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // mainMenu
            // 
            this.mainMenu.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.mainMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuItmFile,
            this.mnuItmHelp});
            this.mainMenu.Location = new System.Drawing.Point(0, 0);
            this.mainMenu.Name = "mainMenu";
            this.mainMenu.Size = new System.Drawing.Size(754, 34);
            this.mainMenu.TabIndex = 0;
            this.mainMenu.Text = "mainMenu";
            // 
            // mnuItmFile
            // 
            this.mnuItmFile.AutoSize = false;
            this.mnuItmFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuItmClose});
            this.mnuItmFile.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.mnuItmFile.Name = "mnuItmFile";
            this.mnuItmFile.Size = new System.Drawing.Size(50, 30);
            this.mnuItmFile.Text = "&File";
            // 
            // mnuItmClose
            // 
            this.mnuItmClose.Name = "mnuItmClose";
            this.mnuItmClose.Size = new System.Drawing.Size(114, 24);
            this.mnuItmClose.Text = "&Close";
            this.mnuItmClose.Click += new System.EventHandler(this.mnuItmClose_Click);
            // 
            // mnuItmHelp
            // 
            this.mnuItmHelp.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuItmAbout});
            this.mnuItmHelp.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.mnuItmHelp.Name = "mnuItmHelp";
            this.mnuItmHelp.Size = new System.Drawing.Size(53, 30);
            this.mnuItmHelp.Text = "&Help";
            // 
            // mnuItmAbout
            // 
            this.mnuItmAbout.Name = "mnuItmAbout";
            this.mnuItmAbout.Size = new System.Drawing.Size(152, 24);
            this.mnuItmAbout.Text = "&About";
            this.mnuItmAbout.Click += new System.EventHandler(this.mnuItmAbout_Click);
            // 
            // tvFolders
            // 
            this.tvFolders.Dock = System.Windows.Forms.DockStyle.Left;
            this.tvFolders.ImageIndex = 0;
            this.tvFolders.ImageList = this.imgListTreeView;
            this.tvFolders.Location = new System.Drawing.Point(0, 34);
            this.tvFolders.Name = "tvFolders";
            this.tvFolders.SelectedImageIndex = 0;
            this.tvFolders.Size = new System.Drawing.Size(275, 408);
            this.tvFolders.TabIndex = 1;
            this.tvFolders.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.tvFolders_AfterSelect);
            // 
            // imgListTreeView
            // 
            this.imgListTreeView.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imgListTreeView.ImageStream")));
            this.imgListTreeView.TransparentColor = System.Drawing.Color.White;
            this.imgListTreeView.Images.SetKeyName(0, "if_Computer2_67977.bmp");
            this.imgListTreeView.Images.SetKeyName(1, "if_removable-usb_2297.bmp");
            this.imgListTreeView.Images.SetKeyName(2, "if_Normal_folder_43546.bmp");
            this.imgListTreeView.Images.SetKeyName(3, "if_Folder_27849.bmp");
            this.imgListTreeView.Images.SetKeyName(4, "if_document_1055071.png");
            this.imgListTreeView.Images.SetKeyName(5, "if_Drive_Windows_56181.bmp");
            this.imgListTreeView.Images.SetKeyName(6, "if_HardDrive_56186.bmp");
            this.imgListTreeView.Images.SetKeyName(7, "if_DVDRom_56193.bmp");
            this.imgListTreeView.Images.SetKeyName(8, "if_USB_Removable_56188.bmp");
            // 
            // lvFolders
            // 
            this.lvFolders.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lvFolders.Location = new System.Drawing.Point(274, 34);
            this.lvFolders.Name = "lvFolders";
            this.lvFolders.Size = new System.Drawing.Size(480, 408);
            this.lvFolders.TabIndex = 2;
            this.lvFolders.UseCompatibleStateImageBehavior = false;
            this.lvFolders.View = System.Windows.Forms.View.Details;
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(754, 442);
            this.Controls.Add(this.lvFolders);
            this.Controls.Add(this.tvFolders);
            this.Controls.Add(this.mainMenu);
            this.ForeColor = System.Drawing.Color.Transparent;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmMain";
            this.Text = "My File Explorer";
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.mainMenu.ResumeLayout(false);
            this.mainMenu.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip mainMenu;
        private System.Windows.Forms.ToolStripMenuItem mnuItmFile;
        private System.Windows.Forms.ToolStripMenuItem mnuItmClose;
        private System.Windows.Forms.ToolStripMenuItem mnuItmHelp;
        private System.Windows.Forms.ToolStripMenuItem mnuItmAbout;
        private System.Windows.Forms.TreeView tvFolders;
        private System.Windows.Forms.ImageList imgListTreeView;
        private System.Windows.Forms.ListView lvFolders;
    }
}

